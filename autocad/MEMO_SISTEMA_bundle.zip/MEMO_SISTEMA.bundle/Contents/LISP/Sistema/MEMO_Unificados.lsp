;;; MEMO SISTEMA 2.1.1 - archivo generado por construir_bundle.py
;;; Origen: @fuente/MEMO_Unificados.lsp

;;; =====================================================================
;;;  MEMO_Unificados.lsp  -  Comandos que agrupan familias de rutinas
;;;
;;;   MTABLA      Una sola entrada para las tablas COP / ASI / CSSA.
;;;               Lee el portapapeles y propone el formato seg�n el
;;;               n�mero de columnas copiadas (5, 7 o 4).
;;;   MAREA       Una sola entrada para los 9 comandos de �reas.
;;;   MBACHEO     Flujo de bacheo paso a paso: dibujar, numerar, cotar,
;;;               hatch, exportar.
;;;   MEMO_CONFIG Edita los valores configurables del sistema.
;;;
;;;  Estos comandos NO reescriben las rutinas originales: las llaman,
;;;  as� el resultado en el dibujo es exactamente el mismo de siempre.
;;; =====================================================================
(vl-load-com)

;;; ---------------------------------------------------------------------
;;; MTABLA
;;; ---------------------------------------------------------------------
(defun c:MTABLA (/ *error* txt cols def fmt)
  (defun *error* (msg)
    (setq memo:*tabla-sin-preguntar* nil)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*EXIT*"))
      (princ (strcat "\nError: " msg)))
    (princ)
  )
  (princ "\n=== MTABLA - Tablas de conceptos ===")
  (setq txt (memo:portapapeles))
  (if txt (setq txt (memo:tsv-normalizar txt)))
  (setq cols (if txt (length (memo:split (car (memo:split txt "\n")) "\t")) 0))
  (if txt
    (princ (strcat "\nPortapapeles: " (itoa (memo:contar-lineas txt)) " fila(s) de "
                   (itoa cols) " columna(s)."))
    (princ "\nEl portapapeles est� vac�o: despu�s podr�s pegar los datos a mano.")
  )
  (setq def
    (cond
      ((= cols 5) "Obras")
      ((= cols 7) "Asipona")
      ((= cols 4) "Ssa")
      ((member (memo:cfg "TABLA_ULTIMO") '("Obras" "Asipona" "Ssa")) (memo:cfg "TABLA_ULTIMO"))
      (T "Obras")
    )
  )
  (princ "\n  Obras         = 5 col. (No.|C�digo|Concepto|Unidad|Precio)")
  (princ "\n  Asipona       = 7 col. (No.|C�digo|Descripci�n|Unidad|P.U.|Cantidad|Importe)")
  (princ "\n  Ssa           = 4 col. (No.|Concepto|Unidad|Cantidad)")
  (setq fmt (memo:opcion "\nFormato de tabla" "Obras Asipona Ssa" def))
  (memo:cfg-set "TABLA_ULTIMO" fmt)
  ;; El usuario ya vio lo que hay en el portapapeles: no volver a preguntar
  (setq memo:*tabla-sin-preguntar* (if txt T nil))
  (memo:llamar (cdr (assoc fmt '(("Obras" . "COP") ("Asipona" . "ASI") ("Ssa" . "CSSA")))))
  (setq memo:*tabla-sin-preguntar* nil)
  (princ)
)

;;; ---------------------------------------------------------------------
;;; MAREA
;;; ---------------------------------------------------------------------
(setq memo:*areas*
  '(("Prefijo"  "HA2"  "�rea de un hatch a un texto, preguntando prefijo")
    ("Rapido"   "HA"   "Igual que Prefijo, con el �ltimo prefijo usado")
    ("M2"       "AM2"  "Actualiza el �rea en m� del texto de un hatch")
    ("Hatch"    "AH"   "Varios hatches: 'AREA DE [TIPO]=[VALOR]M2'")
    ("Contorno" "AC"   "�reas de secciones a partir de contornos")
    ("Tres"     "AS"   "�rea de secci�n por 3 puntos")
    ("Detalle"  "CAS"  "C�lculo con f�rmulas (tri�ngulos, trapecios, c�rculos)")
    ("Valores"  "QA"   "C�lculo r�pido con valores sustituidos")
    ("Exportar" "EA"   "Etiquetar por capa y exportar a CSV/Excel"))
)

(defun c:MAREA (/ def op e)
  (princ "\n=== MAREA - �reas ===")
  (foreach e memo:*areas*
    (princ (strcat "\n  " (car e) (substr "          " 1 (- 10 (strlen (car e))))
                   "(" (cadr e) ")  " (caddr e)))
  )
  (setq def (memo:cfg "AREA_ULTIMO"))
  (if (not (assoc def memo:*areas*)) (setq def "Prefijo"))
  (setq op (memo:opcion "\nTipo de �rea"
                        "Prefijo Rapido M2 Hatch Contorno Tres Detalle Valores Exportar" def))
  (memo:cfg-set "AREA_ULTIMO" op)
  (memo:llamar (cadr (assoc op memo:*areas*)))
  (princ)
)

;;; ---------------------------------------------------------------------
;;; MBACHEO
;;; ---------------------------------------------------------------------
(setq memo:*bacheo*
  '(("Dibujar"  "RS"        "Dibujar rect�ngulos con cotas y hatch")
    ("Numerar"  "RNB"       "Renumerar por vecino m�s cercano")
    ("Cotar"    "COTB"      "Anotar largo y ancho")
    ("Hatch"    "HR"        "Hatch a los rect�ngulos")
    ("Exportar" "EXR"       "Exportar a CSV (�rea, volumen, acumulado)")
    ("Limpiar"  "BTR"       "Borrar textos dentro de rect�ngulos")
    ("Config"   "RS-CONFIG" "Configurar el hatch de RS"))
)

(defun c:MBACHEO (/ op sig paso)
  (princ "\n=== MBACHEO - Flujo de bacheo ===")
  (princ (strcat "\nEspesor para el volumen: " (memo:cfg "BACHEO_ESPESOR")
                 " m (se cambia con MEMO_CONFIG)"))
  (setq sig "Dibujar")
  (while
    (/= "Salir"
        (setq op (memo:opcion "\nPaso" "Dibujar Numerar Cotar Hatch Exportar Limpiar Config Salir" sig)))
    (setq paso (assoc op memo:*bacheo*))
    (princ (strcat "\n--- " (caddr paso) " (" (cadr paso) ") ---"))
    (memo:llamar (cadr paso))
    ;; Proponer el siguiente paso l�gico
    (setq sig
      (cond
        ((= op "Dibujar") "Numerar")
        ((= op "Numerar") "Cotar")
        ((= op "Cotar") "Exportar")
        ((= op "Hatch") "Exportar")
        ((= op "Exportar") "Salir")
        (T "Dibujar")
      )
    )
  )
  (princ)
)

;;; ---------------------------------------------------------------------
;;; MEMO_CONFIG
;;; memo:*cfg-def* = lista de (CLAVE "defecto" "descripci�n" tipo opciones)
;;;   tipo: "NUM" o "TXT"; opciones: "" o "SI,NO,PREGUNTAR"
;;; ---------------------------------------------------------------------
(defun memo:cfg-valido (e v)
  (cond
    ((= (nth 3 e) "NUM") (distof v 2))
    ((/= (nth 4 e) "") (member (strcase v) (memo:split (nth 4 e) ",")))
    (T T)
  )
)

(defun memo:cfg-listar (/ i e v)
  (princ "\n\n===== MEMO_CONFIG - valores configurables =====")
  (setq i 1)
  (foreach e memo:*cfg-def*
    (setq v (memo:cfg (car e)))
    (princ (strcat "\n" (if (< i 10) " " "") (itoa i) ". " (caddr e) ": " v
                   (if (/= v (cadr e)) (strcat "   (defecto " (cadr e) ")") "")))
    (setq i (1+ i))
  )
  (princ "\n===============================================")
)

(defun c:MEMO_CONFIG (/ op i e nuevo)
  (while
    (progn
      (memo:cfg-listar)
      (setq op (getstring "\nN�mero a cambiar, R = restablecer todo, Enter = salir: "))
      (/= op "")
    )
    (cond
      ((= (strcase op) "R")
       (initget "Si No")
       (if (= (getkword "\n�Restablecer todos los valores por defecto? [Si/No] <No>: ") "Si")
         (progn
           (foreach e memo:*cfg-def* (memo:cfg-set (car e) ""))
           (princ "\nValores restablecidos.")
         )
       )
      )
      ((and (> (setq i (atoi op)) 0) (setq e (nth (1- i) memo:*cfg-def*)))
       (if (/= (nth 4 e) "") (princ (strcat "\nOpciones: " (nth 4 e))))
       (setq nuevo (getstring T (strcat "\n" (caddr e) " <" (memo:cfg (car e)) ">: ")))
       (cond
         ((= nuevo ""))
         ((memo:cfg-valido e nuevo)
          (memo:cfg-set (car e) (if (/= (nth 4 e) "") (strcase nuevo) nuevo))
          (princ "\nGuardado."))
         (T (princ "\nValor no v�lido; no se cambi�."))
       )
      )
      (T (princ "\nOpci�n no v�lida."))
    )
  )
  (princ "\nLos cambios se aplican la pr�xima vez que ejecutes cada comando.")
  (princ)
)

(princ)
