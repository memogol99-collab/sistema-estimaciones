;;; MEMO SISTEMA 2.5.1 - archivo generado por construir_bundle.py
;;; Origen: @fuente/MEMO_Lib.lsp

;;; =====================================================================
;;;  MEMO_Lib.lsp  -  Biblioteca com�n del MEMO SISTEMA
;;;  Se carga al abrir cada dibujo (es peque�a). Todas las funciones
;;;  llevan el prefijo memo: para no chocar con ning�n otro LISP.
;;;
;;;   Configuraci�n : memo:cfg  memo:cfg-num  memo:cfg-set
;;;   Portapapeles  : memo:portapapeles
;;;   Tablas Excel  : memo:tsv-normalizar  memo:leer-datos-tabla  memo:pedir-texto
;;;   Ejecuci�n     : memo:ejecutar  memo:envolver (Deshacer agrupado y ESC seguro)
;;;   Utilidades    : memo:split  memo:recortar  memo:contar-lineas
;;;                   memo:llamar  memo:opcion
;;; =====================================================================
(vl-load-com)

;;; ---------------------------------------------------------------------
;;; CONFIGURACI�N
;;; Los valores por defecto (memo:*cfg-def*) los define MEMO_Cargador.lsp
;;; a partir de catalogo.py. Lo que el usuario cambia con MEMO_CONFIG se
;;; guarda con setenv (registro de Windows, perfil de AutoCAD), as� que
;;; sobrevive a reinstalar o actualizar el sistema.
;;; ---------------------------------------------------------------------
(defun memo:cfg (clave / v d)
  (setq v (getenv (strcat "MEMO_" clave)))
  (if (and v (/= v ""))
    v
    (if (setq d (assoc clave memo:*cfg-def*)) (cadr d) "")
  )
)

(defun memo:cfg-num (clave / v)
  (setq v (distof (memo:cfg clave) 2))
  (if v v 0.0)
)

(defun memo:cfg-set (clave valor)
  (setenv (strcat "MEMO_" clave) valor)
)

;;; ---------------------------------------------------------------------
;;; UTILIDADES
;;; ---------------------------------------------------------------------
(defun memo:split (txt sep / pos res)
  (while (setq pos (vl-string-search sep txt))
    (setq res (cons (substr txt 1 pos) res)
          txt (substr txt (+ pos 1 (strlen sep))))
  )
  (reverse (cons txt res))
)

(defun memo:recortar (txt n)
  (if (> (strlen txt) n) (strcat (substr txt 1 (- n 3)) "...") txt)
)

(defun memo:contar-lineas (txt)
  (length (vl-remove "" (memo:split txt "\n")))
)

;; Ejecuta un comando MEMO (aunque todav�a no est� cargado)
(defun memo:llamar (cmd)
  (eval (list (read (strcat "C:" cmd))))
)

;; Pregunta una opci�n con valor por defecto. kws = "Uno Dos Tres"
(defun memo:opcion (msg kws def / r)
  (initget kws)
  (setq r (getkword (strcat msg " [" (vl-string-translate " " "/" kws) "] <" def ">: ")))
  (if r r def)
)

;;; ---------------------------------------------------------------------
;;; PORTAPAPELES
;;; 1) Objeto COM "htmlfile" (r�pido, sin ventanas).
;;; 2) Si no existe en el equipo: PowerShell Get-Clipboard (m�s lento).
;;; Devuelve el texto copiado o nil.
;;; ---------------------------------------------------------------------
(defun memo:portapapeles-html (/ html res)
  (setq res
    (vl-catch-all-apply
      '(lambda ()
         (setq html (vlax-create-object "htmlfile"))
         (vlax-invoke
           (vlax-get (vlax-get html 'ParentWindow) 'ClipboardData)
           'GetData "Text")
       )
    )
  )
  (if html (vl-catch-all-apply 'vlax-release-object (list html)))
  (if (and (not (vl-catch-all-error-p res)) (= (type res) 'STR) (/= res ""))
    res
  )
)

(defun memo:portapapeles-ps (/ tmp wsh f lin txt)
  (setq tmp (vl-filename-mktemp "memo_pp" nil ".txt"))
  (vl-catch-all-apply
    '(lambda ()
       (setq wsh (vlax-create-object "WScript.Shell"))
       (vlax-invoke-method wsh 'Run
         (strcat "powershell -NoProfile -ExecutionPolicy Bypass -Command "
                 "\"Get-Clipboard -Raw | Set-Content -Encoding Default -LiteralPath '"
                 tmp "'\"")
         0 :vlax-true)
     )
  )
  (if wsh (vl-catch-all-apply 'vlax-release-object (list wsh)))
  (if (and (findfile tmp) (setq f (open tmp "r")))
    (progn
      (while (setq lin (read-line f))
        (setq txt (if txt (strcat txt "\n" lin) lin))
      )
      (close f)
      (vl-file-delete tmp)
    )
  )
  (if (and txt (/= txt "")) txt)
)

(defun memo:portapapeles ()
  (cond ((memo:portapapeles-html)) ((memo:portapapeles-ps)))
)

;;; ---------------------------------------------------------------------
;;; TEXTO COPIADO DE EXCEL (columnas separadas por TAB)
;;; - Quita los retornos de carro (\r).
;;; - Las celdas con salto de l�nea interno vienen "entre comillas":
;;;   se unen en una sola l�nea y se quitan las comillas.
;;; - Elimina l�neas vac�as.
;;; Devuelve las filas separadas por \n (con \n final, igual que cuando
;;; se pegaban a mano), o nil si no hay datos.
;;; ---------------------------------------------------------------------
(defun memo:tsv-normalizar (txt / cs acc dentro c res)
  (setq cs (vl-string->list txt))
  (while cs
    (setq c (car cs) cs (cdr cs))
    (cond
      ((= c 13))                                        ; \r
      ((= c 34)                                         ; comilla
       (cond
         ((and dentro (= (car cs) 34))                  ; "" escapada
          (setq acc (cons 34 acc) cs (cdr cs)))
         (dentro (setq dentro nil))
         ((or (null acc) (member (car acc) '(9 10)))    ; inicio de celda
          (setq dentro T))
         (T (setq acc (cons c acc)))))
      ((and dentro (= c 10)) (setq acc (cons 32 acc)))  ; salto dentro de celda
      (T (setq acc (cons c acc)))
    )
  )
  (foreach lin (memo:split (vl-list->string (reverse acc)) "\n")
    (if (/= (vl-string-trim " \t" lin) "")
      (setq res (cons lin res))
    )
  )
  (if res
    (apply 'strcat (mapcar '(lambda (l) (strcat l "\n")) (reverse res)))
  )
)

;;; ---------------------------------------------------------------------
;;; DATOS PARA TABLAS (COP, ASI, CSSA y MTABLA)
;;; ncols = columnas que espera la tabla (5 COP, 7 ASI, 4 CSSA).
;;; Seg�n TABLA_PORTAPAPELES:
;;;   SI        -> usa lo copiado directamente (s�lo pregunta si el n�mero
;;;                de columnas no coincide con lo que espera la tabla)
;;;   PREGUNTAR -> muestra lo copiado y pregunta antes de usarlo
;;;   NO        -> como antes: pegar con Ctrl+V y Enter 2 veces
;;; Si no hay nada copiado, tambi�n se pega a mano.
;;; ---------------------------------------------------------------------
(defun memo:leer-datos-tabla (ncols / modo txt n c resp entrada linea)
  (setq modo (strcase (memo:cfg "TABLA_PORTAPAPELES")))
  (if (/= modo "NO")
    (progn
      (setq txt (memo:portapapeles))
      (if txt (setq txt (memo:tsv-normalizar txt)))
    )
  )
  (if txt
    (progn
      (setq n (memo:contar-lineas txt)
            c (length (memo:split (car (memo:split txt "\n")) "\t")))
      (princ (strcat "\nDatos del portapapeles: " (itoa n) " fila(s), " (itoa c) " columna(s)."))
      (princ (strcat "\n  1a fila: " (memo:recortar (vl-string-translate "\t" "|" (car (memo:split txt "\n"))) 75)))
      (cond
        ((and ncols (/= c ncols))
         (princ (strcat "\n  ATENCI�N: esta tabla espera " (itoa ncols) " columnas."))
         (if (= (memo:opcion "\n�Usar de todas formas los datos del portapapeles?" "Si No" "No") "No")
           (setq txt nil)))
        ((and (= modo "PREGUNTAR") (not memo:*tabla-sin-preguntar*))
         (if (= (memo:opcion "\n�Usar los datos del portapapeles?" "Si No" "Si") "No")
           (setq txt nil)))
      )
    )
  )
  (setq memo:*tabla-sin-preguntar* nil)
  (if (not txt)
    (progn
      (princ "\nPega los datos (Ctrl+V) y presiona Enter 2 veces:")
      (setq entrada "" linea (getstring T "\n>>> "))
      (while (and linea (/= linea ""))
        (setq entrada (strcat entrada linea "\n")
              linea (getstring T ">>> "))
      )
      (setq txt entrada)
    )
  )
  txt
)

;;; ---------------------------------------------------------------------
;;; TEXTO CON EL PORTAPAPELES COMO VALOR POR DEFECTO (CTX y otros)
;;; Si lo copiado es una sola l�nea corta, Enter la usa.
;;; ---------------------------------------------------------------------
(defun memo:pedir-texto (msg / clip r)
  (setq clip (memo:portapapeles))
  (if clip (setq clip (vl-string-trim " \t\r\n" clip)))
  (if (and clip (/= clip "") (<= (strlen clip) 250)
           (not (vl-string-search "\n" clip)) (not (vl-string-search "\t" clip)))
    (progn
      (setq r (getstring T (strcat msg " <" (memo:recortar clip 40) ">: ")))
      (if (= r "") clip r))
    (getstring T (strcat msg ": "))
  )
)

;;; ---------------------------------------------------------------------
;;; EJECUCI�N SEGURA DE TODOS LOS COMANDOS MEMO
;;; Cuando se carga un archivo, cada comando se "envuelve" para que:
;;;  1) todo lo que hace quede en UN solo paso de Deshacer (U);
;;;  2) si se cancela con ESC o hay un error, se restauren las variables
;;;     (OSMODE, capa, estilo de texto, CMDECHO, REGENMODE, etc.).
;;; Si el comando termina bien, no se toca nada: queda como lo dej�.
;;; Se desactiva con MEMO_CONFIG -> DESHACER_AGRUPADO = NO.
;;; ---------------------------------------------------------------------
(setq memo:*vars-guardar*
  '("CMDECHO" "OSMODE" "CLAYER" "TEXTSTYLE" "SNAPMODE" "SNAPUNIT" "ORTHOMODE"
    "REGENMODE" "CECOLOR" "FILEDIA" "CMDDIA" "DIMZIN" "HIGHLIGHT" "UCSFOLLOW"
    "PDMODE" "PDSIZE" "HPNAME" "HPSCALE" "HPANG"))

(defun memo:doc () (vla-get-ActiveDocument (vlax-get-acad-object)))

(defun memo:guardar-vars ()
  (vl-remove nil
    (mapcar '(lambda (v / x)
               (setq x (vl-catch-all-apply 'getvar (list v)))
               (if (not (vl-catch-all-error-p x)) (cons v x)))
            memo:*vars-guardar*))
)

(defun memo:restaurar-vars (lst)
  (foreach par lst
    (if (not (equal (getvar (car par)) (cdr par)))
      (vl-catch-all-apply 'setvar (list (car par) (cdr par))))
  )
)

;; Llama a la versi�n original del comando
(defun memo:llamar-orig (cmd)
  (eval (list (read (strcat "MEMO:ORIG-" cmd))))
)

;; memo:dentro es una variable LOCAL de memo:ejecutar-externo: por el
;; alcance din�mico de AutoLISP, un comando llamado desde otro (MTABLA ->
;; COP, FH -> FUSIONHATCH) la ve en T y no abre un segundo grupo. Al
;; terminar o cancelar, AutoLISP la devuelve sola a nil.
(defun memo:ejecutar (cmd)
  (if memo:dentro
    (memo:llamar-orig cmd)
    (memo:ejecutar-externo cmd)
  )
)

(defun memo:ejecutar-externo (cmd / *error* memo:dentro vars doc res)
  (setq memo:dentro T
        doc (memo:doc)
        vars (memo:guardar-vars))
  ;; Si la vez anterior el comando termin� por su propio manejador de
  ;; errores, el grupo de Deshacer qued� abierto: cerrarlo ahora.
  (if memo:*marca-abierta*
    (vl-catch-all-apply 'vla-EndUndoMark (list doc)))
  (defun *error* (msg)
    (memo:restaurar-vars vars)
    (vl-catch-all-apply 'vla-EndUndoMark (list doc))
    (setq memo:*marca-abierta* nil)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*EXIT*,*BREAK*,*SALIR*,*ABORT*,*QUITAR*"))
      (princ (strcat "\nError en " cmd ": " msg)))
    (princ)
  )
  (vl-catch-all-apply 'vla-StartUndoMark (list doc))
  (setq memo:*marca-abierta* T)
  (setq res (memo:llamar-orig cmd))
  (vl-catch-all-apply 'vla-EndUndoMark (list doc))
  (setq memo:*marca-abierta* nil)
  res
)

;; Envuelve los comandos de un archivo reci�n cargado (una sola vez)
(defun memo:envolver (cmds / sym)
  (if (/= (strcase (memo:cfg "DESHACER_AGRUPADO")) "NO")
    (foreach cmd cmds
      (setq sym (read (strcat "C:" cmd)))
      (if (and (eval sym)
               (not (member cmd memo:*envueltos*))
               (not (and memo:es-stub-p (memo:es-stub-p cmd))))
        (progn
          (set (read (strcat "MEMO:ORIG-" cmd)) (eval sym))
          (eval (list 'defun sym nil (list 'memo:ejecutar cmd)))
          (setq memo:*envueltos* (cons cmd memo:*envueltos*))
        )
      )
    )
  )
)

(princ)
