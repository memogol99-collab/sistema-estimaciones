;;; MEMO SISTEMA 2.1.0 - archivo generado por construir_bundle.py
;;; Origen: LISP_Secciones/Extraer Area de Cont ( AC ).LSP

; MACRO PARA C�LCULO Y ACTUALIZACI�N AUTOM�TICA DE �REAS DE SECCIONES TRANSVERSALES
(DEFUN C:AC (/ LIP CAD1 A N T1 C AC ACA AB ASR AT ent lastEnt areaValue oldLast 
                cadenamientoPoint ss i entText textObj textPos dist minDist foundText oldText newText)
  (vl-load-com)
  
  ; FUNCI�N PARA CALCULAR �REA DE CUALQUIER OBJETO
  (defun getObjectArea (entName)
    (if entName
      (progn
        (setq areaValue 0.0)
        (setq obj (vlax-ename->vla-object entName))
        (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-get-Area (list obj)))
          (progn
            (command "._AREA" "_O" entName)
            (setq areaValue (getvar "AREA"))
          )
          (setq areaValue (vla-get-Area obj))
        )
        areaValue
      )
      0.0
    )
  )

  ; FUNCI�N PARA REEMPLAZAR VALOR DESPU�S DEL PATR�N ESPEC�FICO
  (defun replaceAfterPattern (oldText pattern newValue / patternPos equalsPos valueStart valueEnd)
    (setq patternPos (vl-string-search pattern oldText))
    (if patternPos
      (progn
        (setq equalsPos (+ patternPos (strlen pattern)))
        ; Buscar el inicio del valor num�rico (despu�s del "=")
        (setq valueStart equalsPos)
        ; Buscar el final del valor num�rico (hasta espacio o fin de texto)
        (setq valueEnd (strlen oldText))
        (setq i equalsPos)
        (while (and (< i (strlen oldText))
                   (not (wcmatch (substr oldText (1+ i) 1) " ,")))
          (setq i (1+ i))
        )
        (setq valueEnd i)
        
        ; Reemplazar solo la parte del valor
        (strcat (substr oldText 1 valueStart)
                newValue
                (substr oldText (1+ valueEnd)))
      )
      oldText  ; Si no encuentra el patr�n, devolver texto original
    )
  )

  ; FUNCI�N PARA BUSCAR Y ACTUALIZAR EL TEXTO M�S CERCANO CON EL PATR�N ESPEC�FICO
  (defun updateLayerText (newValue pattern layerName / ss i entText textObj textPos dist minDist foundText oldText newText)
    (setq minDist 1e308
          foundText nil
    )
    
    ; Buscar todos los textos en el dibujo
    (if (setq ss (ssget "_X" '((0 . "TEXT,MTEXT"))))
      (progn
        (repeat (setq i (sslength ss))
          (setq entText (ssname ss (setq i (1- i))))
          (setq textObj (vlax-ename->vla-object entText))
          (setq textPos (vlax-get textObj 'InsertionPoint))
          (setq dist (distance cadenamientoPoint (list (car textPos) (cadr textPos))))
          
          ; Verificar si el texto contiene el patr�n y est� m�s cerca que los anteriores
          (if (and (wcmatch (setq oldText (vla-get-TextString textObj)) (strcat "*" pattern "*"))
                   (< dist minDist))
            (progn
              (setq minDist dist)
              (setq foundText entText)
            )
          )
        )
        
        ; Si se encontr� un texto con el patr�n, actualizarlo
        (if foundText
          (progn
            (setq textObj (vlax-ename->vla-object foundText))
            (setq oldText (vla-get-TextString textObj))
            (setq newText (replaceAfterPattern oldText pattern newValue))
            (vla-put-TextString textObj newText)
            (princ (strcat "\n>>> " layerName " actualizado: " oldText " -> " newText))
          )
          (princ (strcat "\n>>> " layerName ": No se encontr� texto con '" pattern "' cercano al cadenamiento"))
        )
      )
      (princ (strcat "\n>>> " layerName ": No se encontraron textos en el dibujo"))
    )
  )

  ; ========== PRIMERO SELECCIONAR CADENAMIENTO ==========
  (princ "\nSelecciona el texto del cadenamiento: ")
  (SETQ ent (ENTSEL "\nSelecciona el texto del cadenamiento: "))
  (if ent
    (progn
      (SETQ LIP (ENTGET (CAR ent)))
      (SETQ CAD1 (CDR (ASSOC 1 LIP)))
      ; Guardar la posici�n del cadenamiento para buscar textos cercanos
      (setq cadenamientoPoint (cdr (assoc 10 LIP)))
      (princ (strcat "\nCadenamiento capturado: " CAD1))
    )
    (progn
      (princ "\n>>> No se seleccion� ning�n texto. Saliendo...")
      (exit)
    )
  )

  ; ========== APAGAR CAPAS TEMPORALES ==========
  (princ "\nApagando capas temporales...")
  (command "._-LAYER" "_OFF" "XGRID" "")
  (command "._-LAYER" "_OFF" "APV-Cotas" "")
  (command "._-LAYER" "_OFF" "XGRIDT" "")
  (command "._-LAYER" "_OFF" "APV-Textosdatos" "")
  (command "._-LAYER" "_OFF" "XFG" "")
  (princ " >>> Capas apagadas")

  ; ========== AREA DE CORTE ==========
  (princ "\n--- AREA DE CORTE ---")
  (SETQ A (GETINT "\n�Cu�ntas �reas de corte son? : "))
  (SETQ N 1)
  (SETQ C 0.0)
  
  (if (or (not A) (= A 0))
    (progn
      (SETQ AC "0.00")
      (princ "\n�rea de corte: 0.00")
    )
    (progn
      (while (<= N A)
        (princ (strcat "\n�rea " (itoa N) " de " (itoa A) " - Toca dentro del �rea de corte: "))
        
        (setq oldLast (entlast))
        (command "._BOUNDARY" PAUSE "")
        
        (if (not (equal oldLast (entlast)))
          (progn
            (SETQ lastEnt (entlast))
            (SETQ T1 (getObjectArea lastEnt))
            (command "._ERASE" lastEnt "")
            (SETQ C (+ T1 C))
            (princ (strcat "�rea calculada: " (rtos T1 2 2)))
          )
          (progn
            (princ ">>> No se pudo crear el boundary. Intenta de nuevo.")
            (setq N (1- N))
          )
        )
        (SETQ N (1+ N))
      )
      (SETQ AC (RTOS C 2 2))
      (princ (strcat "\n�rea TOTAL de corte: " AC " m�"))
      
      ; ACTUALIZAR AUTOM�TICAMENTE EL TEXTO M�S CERCANO CON "AC="
      (updateLayerText AC "AC=" "CORTE")
    )
  )
  
  ; ========== CONFIGURAR CAPAS PARA CARPETA ASFALTICA ==========
  (command "._-LAYER" "_ON" "XFG" "")
  (command "._-LAYER" "_OFF" "AC" "")
  (command "._-LAYER" "_OFF" "XEG" "")

  ; ========== CARPETA ASFALTICA ==========
  (princ "\n--- CARPETA ASFALTICA ---")
  (SETQ A (GETINT "\n�Cu�ntas �reas de carpeta asf�ltica son? : "))
  (SETQ N 1)
  (SETQ C 0.0)
  
  (if (or (not A) (= A 0))
    (progn
      (SETQ ACA "0.00")
      (princ "\n�rea carpeta asf�ltica: 0.00")
    )
    (progn
      (while (<= N A)
        (princ (strcat "\n�rea " (itoa N) " de " (itoa A) " - Toca dentro del �rea de carpeta asf�ltica: "))
        
        (setq oldLast (entlast))
        (command "._BOUNDARY" PAUSE "")
        
        (if (not (equal oldLast (entlast)))
          (progn
            (SETQ lastEnt (entlast))
            (SETQ T1 (getObjectArea lastEnt))
            (command "._ERASE" lastEnt "")
            (SETQ C (+ T1 C))
            (princ (strcat "�rea calculada: " (rtos T1 2 2)))
          )
          (progn
            (princ ">>> No se pudo crear el boundary. Intenta de nuevo.")
            (setq N (1- N))
          )
        )
        (SETQ N (1+ N))
      )
      (SETQ ACA (RTOS C 2 2))
      (princ (strcat "\n�rea TOTAL carpeta asf�ltica: " ACA " m�"))
      
      ; ACTUALIZAR AUTOM�TICAMENTE EL TEXTO M�S CERCANO CON "ACA="
      (updateLayerText ACA "ACA=" "CARPETA ASFALTICA")
    )
  )

  ; ========== BASE ==========
  (princ "\n--- BASE ---")
  (SETQ A (GETINT "\n�Cu�ntas �reas de base son? : "))
  (SETQ N 1)
  (SETQ C 0.0)
  
  (if (or (not A) (= A 0))
    (progn
      (SETQ AB "0.00")
      (princ "\n�rea base: 0.00")
    )
    (progn
      (while (<= N A)
        (princ (strcat "\n�rea " (itoa N) " de " (itoa A) " - Toca dentro del �rea de base: "))
        
        (setq oldLast (entlast))
        (command "._BOUNDARY" PAUSE "")
        
        (if (not (equal oldLast (entlast)))
          (progn
            (SETQ lastEnt (entlast))
            (SETQ T1 (getObjectArea lastEnt))
            (command "._ERASE" lastEnt "")
            (SETQ C (+ T1 C))
            (princ (strcat "�rea calculada: " (rtos T1 2 2)))
          )
          (progn
            (princ ">>> No se pudo crear el boundary. Intenta de nuevo.")
            (setq N (1- N))
          )
        )
        (SETQ N (1+ N))
      )
      (SETQ AB (RTOS C 2 2))
      (princ (strcat "\n�rea TOTAL base: " AB " m�"))
      
      ; ACTUALIZAR AUTOM�TICAMENTE EL TEXTO M�S CERCANO CON "AB="
      (updateLayerText AB "AB=" "BASE")
    )
  )

  ; ========== SUBRASANTE ==========
  (princ "\n--- SUBRASANTE ---")
  (SETQ A (GETINT "\n�Cu�ntas �reas de subrasante son? : "))
  (SETQ N 1)
  (SETQ C 0.0)
  
  (if (or (not A) (= A 0))
    (progn
      (SETQ ASR "0.00")
      (princ "\n�rea subrasante: 0.00")
    )
    (progn
      (while (<= N A)
        (princ (strcat "\n�rea " (itoa N) " de " (itoa A) " - Toca dentro del �rea de subrasante: "))
        
        (setq oldLast (entlast))
        (command "._BOUNDARY" PAUSE "")
        
        (if (not (equal oldLast (entlast)))
          (progn
            (SETQ lastEnt (entlast))
            (SETQ T1 (getObjectArea lastEnt))
            (command "._ERASE" lastEnt "")
            (SETQ C (+ T1 C))
            (princ (strcat "�rea calculada: " (rtos T1 2 2)))
          )
          (progn
            (princ ">>> No se pudo crear el boundary. Intenta de nuevo.")
            (setq N (1- N))
          )
        )
        (SETQ N (1+ N))
      )
      (SETQ ASR (RTOS C 2 2))
      (princ (strcat "\n�rea TOTAL subrasante: " ASR " m�"))
      
      ; ACTUALIZAR AUTOM�TICAMENTE EL TEXTO M�S CERCANO CON "ASR="
      (updateLayerText ASR "ASR=" "SUBRASANTE")
    )
  )

  ; ========== CONFIGURAR CAPAS PARA TERRAPLEN ==========
  (command "._-LAYER" "_ON" "XEG" "")
  (command "._-LAYER" "_ON" "AC" "")

  ; ========== TERRAPLEN ==========
  (princ "\n--- TERRAPLEN ---")
  (SETQ A (GETINT "\n�Cu�ntas �reas de terraplen son? : "))
  (SETQ N 1)
  (SETQ C 0.0)
  
  (if (or (not A) (= A 0))
    (progn
      (SETQ AT "0.00")
      (princ "\n�rea terrapl�n: 0.00")
    )
    (progn
      (while (<= N A)
        (princ (strcat "\n�rea " (itoa N) " de " (itoa A) " - Toca dentro del �rea de terraplen: "))
        
        (setq oldLast (entlast))
        (command "._BOUNDARY" PAUSE "")
        
        (if (not (equal oldLast (entlast)))
          (progn
            (SETQ lastEnt (entlast))
            (SETQ T1 (getObjectArea lastEnt))
            (command "._ERASE" lastEnt "")
            (SETQ C (+ T1 C))
            (princ (strcat "�rea calculada: " (rtos T1 2 2)))
          )
          (progn
            (princ ">>> No se pudo crear el boundary. Intenta de nuevo.")
            (setq N (1- N))
          )
        )
        (SETQ N (1+ N))
      )
      (SETQ AT (RTOS C 2 2))
      (princ (strcat "\n�rea TOTAL terrapl�n: " AT " m�"))
      
      ; ACTUALIZAR AUTOM�TICAMENTE EL TEXTO M�S CERCANO CON "AT="
      (updateLayerText AT "AT=" "TERRAPLEN")
    )
  )

  ; ========== RESTAURAR TODAS LAS CAPAS ==========
  (princ "\nRestaurando todas las capas...")
  (command "._-LAYER" "_ON" "*" "")
  (princ " >>> Todas las capas restauradas")

  ; ========== RESUMEN FINAL ==========
  (princ "\n--- RESUMEN FINAL ---")
  (princ (strcat "\nCadenamiento: " CAD1))
  (princ (strcat "\nCorte: " AC " m�"))
  (princ (strcat "\nCarpeta Asf�ltica: " ACA " m�"))
  (princ (strcat "\nBase: " AB " m�"))
  (princ (strcat "\nSubrasante: " ASR " m�"))
  (princ (strcat "\nTerrapl�n: " AT " m�"))
  (princ "\n>>> �PROCESO COMPLETADO! Todos los valores han sido actualizados autom�ticamente.")
  
  (princ)
)