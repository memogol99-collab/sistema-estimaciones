;;; MEMO SISTEMA 2.1.0 - archivo generado por construir_bundle.py
;;; Origen: LISP_Topografia/CLIPIT.LSP

(defun C:CLIPIT ()
  (princ "\nSelecciona el rect�ngulo (per�metro de recorte): ")
  (setq rectangulo (entsel))
  
  (if rectangulo
    (progn
      (setq rectangulo_ent (car rectangulo))
      
      (princ "\nSelecciona la imagen a recortar: ")
      (setq imagen (entsel))
      
      (if imagen
        (progn
          (setq imagen_ent (car imagen))
          
          ;; Obtener la informaci�n necesaria del rect�ngulo
          (setq rectangulo_data (entget rectangulo_ent))
          (setq tipo_rectangulo (cdr (assoc 0 rectangulo_data)))
          
          ;; Verificar si el rect�ngulo es una polil�nea cerrada
          (if (eq tipo_rectangulo "LWPOLYLINE")
            (progn
              ;; Recortar la imagen usando el rect�ngulo
              (command "IMAGECLIP" imagen_ent "" "P" rectangulo_ent "")
              (princ "\nImagen recortada exitosamente.")
            )
            (princ "\nEl per�metro debe ser una polil�nea cerrada.")
          )
        )
        (princ "\nNo se seleccion� ninguna imagen.")
      )
    )
    (princ "\nNo se seleccion� ning�n rect�ngulo.")
  )
  (princ)
)

(princ "\nComando CLIPIMAGE_RECT cargado. Escribe CLIPIMAGE_RECT para ejecutar.")
(princ)